using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerController : MonoBehaviour
{
    private Rigidbody2D rb;
    [SerializeField]
    private float runSpeed = 5;
    [SerializeField]
    private float jumpSpeed = 5;

    private Animator anim;
    private float eps = Mathf.Epsilon;
    private bool isGround = true; //�ж��Ӵ������
    private BoxCollider2D feetCol;

    private float vSpeedSmoothVelocity;




    void Start()
    {
        rb = GetComponent<Rigidbody2D>();
        anim = GetComponent<Animator>();
        feetCol = GetComponent<BoxCollider2D>();
    }

    //��
    void Run()
    {
        float movedir = Input.GetAxisRaw("Horizontal");
        rb.velocity = new Vector2(movedir * runSpeed, rb.velocity.y);
    }
    //���߶���
    void WalkAnim()
    {
        anim.SetFloat("hSpeed", Mathf.Abs(rb.velocity.x));
    }
    void JumpAnim()
    {
        if (anim.GetBool("isJump"))
        {
            anim.SetFloat("vSpeed", rb.velocity.y);
        }
    }
    //��ת
    void Filp()
    {
        if(rb.velocity.x > eps)
        {
            transform.localRotation = Quaternion.Euler(0, 0, 0);
        }
        else if(rb.velocity.x < -eps)
        {
            transform.localRotation = Quaternion.Euler(0, 180, 0);
        }  

    }
    void CheckIsGround()
    {
        isGround = feetCol.IsTouchingLayers(LayerMask.GetMask("Ground"));
        anim.SetBool("isJump", !isGround);
        //print(isGround);
    }

    //��
    void Jump()
    {
        if(isGround && Input.GetButtonDown("Jump"))
        {
            rb.velocity = new Vector2(rb.velocity.x, jumpSpeed);
        }
    }

    void Update()
    {
        Run();
        Filp();
        WalkAnim();
        CheckIsGround();
        Jump();
        JumpAnim();
    }
}
